'use client';

import { useState } from 'react';
import { Menu, X, MessageCircle } from 'lucide-react';
import Image from 'next/image';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const menuItems = [
    {
      title: 'Servicios',
      href: '#servicios',
      submenu: [
        { title: 'Piscinas & Jacuzzis', href: '#servicios' },
        { title: 'Domos Geodésicos', href: '#servicios' },
        { title: 'Chalets Enchante', href: '#servicios' },
      ]
    },
    { title: 'Proyectos', href: '#proyectos' },
    { title: '¿Por Qué Nosotros?', href: '#confianza' },
    { title: 'Preguntas', href: '#faq' },
    { title: 'Contacto', href: '#contacto' },
  ];

  const handleWhatsAppClick = () => {
    const message = encodeURIComponent('Hola! Me interesa conocer más sobre sus servicios de construcción.');
    window.open(`https://wa.me/18492528368?text=${message}`, '_blank');
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-pazos-navy shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16 lg:h-20">
          {/* Logo */}
          <div className="flex-shrink-0">
            <a href="#" className="flex items-center space-x-3">
              <Image
                src="/images/Logo Pazos Holding.webp"
                alt="Pazos Holding Logo"
                width={50}
                height={50}
                className="h-10 w-auto lg:h-12"
                priority
              />
              <div className="hidden sm:block">
                <h1 className="text-white text-xl lg:text-2xl font-bold">
                  Pazos<span className="text-pazos-yellow">RD</span>
                </h1>
                <p className="text-pazos-yellow text-xs font-medium">Construcción Especializada</p>
              </div>
            </a>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex lg:space-x-8">
            {menuItems.map((item) => (
              <div key={item.title} className="relative group">
                <a
                  href={item.href}
                  className="text-white hover:text-pazos-yellow transition-colors duration-200 py-2 px-3 rounded-md text-sm font-medium"
                >
                  {item.title}
                </a>
                {item.submenu && (
                  <div className="invisible group-hover:visible absolute left-0 top-full mt-2 w-48 bg-white rounded-md shadow-lg py-2 z-50">
                    {item.submenu.map((subitem) => (
                      <a
                        key={subitem.title}
                        href={subitem.href}
                        className="block px-4 py-2 text-sm text-gray-700 hover:bg-pazos-yellow hover:text-pazos-navy transition-colors duration-200"
                      >
                        {subitem.title}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </nav>

          {/* Desktop WhatsApp CTA */}
          <div className="hidden lg:flex">
            <button
              onClick={handleWhatsAppClick}
              className="bg-pazos-whatsapp hover:bg-pazos-whatsapp-dark text-white px-6 py-2 rounded-full font-medium transition-all duration-300 flex items-center space-x-2 shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              <MessageCircle size={18} />
              <span>Cotiza por WhatsApp</span>
            </button>
          </div>

          {/* Mobile WhatsApp + Menu */}
          <div className="lg:hidden flex items-center space-x-3">
            {/* Mobile WhatsApp Button */}
            <button
              onClick={handleWhatsAppClick}
              className="whatsapp-button p-3 flex items-center justify-center"
              aria-label="Contactar por WhatsApp"
            >
              <MessageCircle size={20} />
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={toggleMenu}
              className="text-white hover:text-pazos-yellow p-2"
              aria-label="Abrir menú"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {isMenuOpen && (
        <div className="lg:hidden fixed inset-0 top-16 bg-pazos-navy-dark bg-opacity-95 z-40">
          <div className="px-4 py-6 space-y-1">
            {menuItems.map((item) => (
              <div key={item.title}>
                <a
                  href={item.href}
                  className="block px-3 py-3 text-lg font-medium text-white hover:text-pazos-yellow hover:bg-pazos-navy-dark rounded-md transition-colors duration-200"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.title}
                </a>
                {item.submenu && (
                  <div className="ml-4 space-y-1">
                    {item.submenu.map((subitem) => (
                      <a
                        key={subitem.title}
                        href={subitem.href}
                        className="block px-3 py-2 text-base text-gray-300 hover:text-white rounded-md transition-colors duration-200"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        {subitem.title}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header; 