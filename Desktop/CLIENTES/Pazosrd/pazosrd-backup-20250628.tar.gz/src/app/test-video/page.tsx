export default function TestVideo() {
  return (
    <div className="min-h-screen bg-black flex items-center justify-center">
      <div className="w-full max-w-4xl aspect-video">
        <h1 className="text-white text-2xl mb-4 text-center">Test Video Vimeo</h1>
        
        {/* Test 1: Video con controles */}
        <div className="mb-8">
          <h2 className="text-white mb-2">Con controles:</h2>
          <iframe
            src="https://player.vimeo.com/video/1051259867?h=fc0f3fa380"
            width="100%"
            height="300"
            frameBorder="0"
            allow="autoplay; fullscreen; picture-in-picture"
            allowFullScreen
          ></iframe>
        </div>

        {/* Test 2: Video sin controles (background) */}
        <div className="mb-8">
          <h2 className="text-white mb-2">Sin controles (background):</h2>
          <iframe
            src="https://player.vimeo.com/video/1051259867?h=fc0f3fa380&background=1&autoplay=1&loop=1&muted=1&controls=0"
            width="100%"
            height="300"
            frameBorder="0"
            allow="autoplay; fullscreen; picture-in-picture"
            allowFullScreen
          ></iframe>
        </div>

        {/* Test 3: Video con playsinline */}
        <div>
          <h2 className="text-white mb-2">Con playsinline:</h2>
          <iframe
            src="https://player.vimeo.com/video/1051259867?h=fc0f3fa380&background=1&autoplay=1&loop=1&muted=1&controls=0&playsinline=1"
            width="100%"
            height="300"
            frameBorder="0"
            allow="autoplay; fullscreen; picture-in-picture"
            allowFullScreen
          ></iframe>
        </div>
      </div>
    </div>
  );
} 