import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "PazosRD - Construcción de Piscinas, Domos y Chalets en República Dominicana",
  description: "Construcción personalizada con 27 años de experiencia. Especialistas en piscinas, domos geodésicos y chalets de lujo. Calidad, innovación y satisfacción garantizada.",
  keywords: "piscinas dominicana, domos geodésicos, chalets lujo, construcción personalizada, piscinas concreto, glamping dominicana",
  authors: [{ name: "Pazos Holding" }],
  icons: {
    icon: [
      {
        url: '/images/favicon.webp',
        sizes: '32x32',
        type: 'image/webp',
      }
    ],
    shortcut: '/images/favicon.webp',
    apple: '/images/favicon.webp',
  },
};

export const viewport = {
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
