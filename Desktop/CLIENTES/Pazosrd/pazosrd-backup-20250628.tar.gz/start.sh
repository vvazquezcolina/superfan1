#!/bin/bash

# PazosRD - Script de Inicio Rápido
echo "🚀 Iniciando PazosRD Website..."
echo "================================"

# Verificar si Node.js está instalado
if ! command -v node &> /dev/null; then
    echo "❌ Node.js no está instalado. Por favor instala Node.js 18+ primero."
    exit 1
fi

# Verificar si las dependencias están instaladas
if [ ! -d "node_modules" ]; then
    echo "📦 Instalando dependencias..."
    npm install
fi

echo "🌟 Abriendo http://localhost:3000"
echo "💻 Presiona Ctrl+C para detener el servidor"
echo ""
echo "✅ WhatsApp configurado: +1 (849) 252-8368"
echo "🎯 Sitio listo para generar leads"
echo ""

# Iniciar servidor de desarrollo
npm run dev 