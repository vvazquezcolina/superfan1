'use client';

import { useState } from 'react';
import { ChevronLeft, ChevronRight, Waves, Home, TreePine, MessageCircle, ArrowRight } from 'lucide-react';
import Image from 'next/image';

const ServicesSection = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const services = [
    {
      id: 'piscinas',
      title: 'Piscinas & Jacuzzis',
      subtitle: 'Desde $200 USD mensuales',
      description: 'Diseños personalizados de concreto con sistemas de filtrado de última tecnología. Obra llave en mano en pocas semanas.',
      image: '/images/render de piscina.webp',
      imageAlt: 'Piscina de concreto personalizada con sistema de filtrado moderno',
      icon: Waves,
      features: [
        'Piscinas infinity y estándar',
        'Jacuzzis integrados', 
        'Equipos de filtrado premium',
        'Garantía estructural 5 años',
        'Financiamiento directo disponible'
      ],
      cta: 'Cotiza tu Piscina',
      whatsappMessage: 'Hola! Me interesa una cotización para construcción de piscina de concreto. ¿Podrían enviarme información sobre diseños, precios y financiamiento?',
      marketInsight: 'Con más de 8.3 millones de turistas en RD (+10% vs 2023), la demanda de piscinas privadas está en auge'
    },
    {
      id: 'domos',
      title: 'Domos Geodésicos',
      subtitle: 'Tendencia #1 en Glamping',
      description: 'Estructuras eco-friendly de montaje rápido. Perfectos para turismo experiencial y eventos únicos.',
      image: '/images/Render de Geodésica.webp',
      imageAlt: 'Domo geodésico para glamping en entorno natural',
      icon: TreePine,
      features: [
        'Diseños eco-friendly certificados',
        'Montaje rápido (días vs semanas)',
        'Resistencia anti-huracanes',
        'Ideal para glamping y eventos',
        'ROI comprobado en turismo'
      ],
      cta: 'Consulta tu Domo',
      whatsappMessage: 'Hola! Estoy interesado en domos geodésicos para proyecto turístico/residencial. ¿Podrían enviarme información sobre tamaños, precios y proceso de instalación?',
      marketInsight: 'Proyectos como The Domes Jarabacoa generaron gran atención en 2023 - aprovecha esta tendencia creciente'
    },
    {
      id: 'chalets',
      title: 'Chalets Enchante',
      subtitle: 'Cabañas de Lujo Prefabricadas',
      description: 'Más baratas de construir y mantener que construcción tradicional. Diseños elegantes personalizables.',
      image: '/images/Render Chalet.webp',
      imageAlt: 'Chalet prefabricado de lujo con diseño elegante',
      icon: Home,
      features: [
        'Construcción 50% más rápida',
        'Costos reducidos vs tradicional',
        'Diseños totalmente personalizables',
        'Materiales premium importados',
        'Perfecto para rentas turísticas'
      ],
      cta: 'Ver Modelos',
      whatsappMessage: 'Hola! Me interesa información sobre Chalets Enchante. ¿Podrían enviarme catálogo de modelos, precios y tiempos de construcción?',
      marketInsight: 'El interés en casas prefabricadas en RD ha aumentado significativamente por ventajas de costo y rapidez'
    }
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % services.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + services.length) % services.length);
  };

  const handleWhatsAppClick = (message: string) => {
    const encodedMessage = encodeURIComponent(message);
    window.open(`https://wa.me/18492528368?text=${encodedMessage}`, '_blank');
  };

  return (
    <section id="servicios" className="py-16 bg-gradient-to-br from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header con insights de mercado */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-pazos-yellow bg-opacity-20 border border-pazos-yellow mb-4">
            <span className="text-pazos-navy font-semibold text-sm">
              🚀 Aprovecha el Boom Turístico de RD
            </span>
          </div>
          
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-pazos-navy mb-4">
            Nuestros Servicios
            <span className="block text-pazos-yellow">Especializados</span>
          </h2>
          
          <p className="text-lg text-gray-600 max-w-3xl mx-auto mb-6">
            Con <strong>27 años de experiencia internacional</strong>, ofrecemos soluciones innovadoras 
            para el mercado dominicano en pleno crecimiento turístico.
          </p>

          {/* Market stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-2xl mx-auto mb-8">
            <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
              <div className="text-2xl font-bold text-pazos-yellow">8.3M+</div>
                        <div className="text-sm text-gray-700">Turistas 2024 (+10%)</div>
        </div>
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="text-2xl font-bold text-pazos-yellow">90.7%</div>
          <div className="text-sm text-gray-700">Ocupación Hotelera</div>
        </div>
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="text-2xl font-bold text-pazos-yellow">27</div>
          <div className="text-sm text-gray-700">Años Experiencia</div>
            </div>
          </div>
        </div>

        {/* Services Carousel para Mobile */}
        <div className="lg:hidden relative">
          <div className="overflow-hidden rounded-xl">
            <div 
              className="flex transition-transform duration-300 ease-in-out"
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            >
                             {services.map((service) => (
                 <div key={service.id} className="w-full flex-shrink-0 p-4">
                  <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                    <div className="relative h-48">
                      <Image
                        src={service.image}
                        alt={service.imageAlt}
                        fill
                        className="object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                      <div className="absolute top-4 left-4">
                        <service.icon className="w-8 h-8 text-pazos-yellow" />
                      </div>
                      <div className="absolute bottom-4 left-4 right-4">
                        <div className="inline-block bg-pazos-yellow text-pazos-navy px-3 py-1 rounded-full text-sm font-semibold mb-2">
                          {service.subtitle}
                        </div>
                      </div>
                    </div>
                    
                    <div className="p-6">
                      <h3 className="text-xl font-bold text-pazos-navy mb-3">{service.title}</h3>
                      <p className="text-gray-600 mb-4">{service.description}</p>
                      
                      <ul className="space-y-2 mb-6">
                        {service.features.map((feature, idx) => (
                          <li key={idx} className="flex items-center text-sm text-gray-600">
                            <div className="w-2 h-2 bg-pazos-yellow rounded-full mr-3"></div>
                            {feature}
                          </li>
                        ))}
                      </ul>

                      <div className="bg-gray-50 rounded-lg p-3 mb-4">
                        <p className="text-xs text-gray-600 italic">{service.marketInsight}</p>
                      </div>
                      
                      <button
                        onClick={() => handleWhatsAppClick(service.whatsappMessage)}
                        className="w-full cta-button flex items-center justify-center space-x-2 py-3 px-4 rounded-lg text-sm font-semibold transform hover:scale-105 transition-all duration-300"
                      >
                        <MessageCircle size={18} />
                        <span>{service.cta}</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Controles del carrusel */}
          <div className="flex justify-center items-center mt-6 space-x-4">
            <button
              onClick={prevSlide}
              className="p-2 rounded-full bg-white shadow-lg hover:bg-gray-50 transition-colors"
            >
              <ChevronLeft className="w-5 h-5 text-pazos-navy" />
            </button>
            
            <div className="flex space-x-2">
              {services.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentSlide(index)}
                  className={`w-2 h-2 rounded-full transition-colors ${
                    index === currentSlide ? 'bg-pazos-yellow' : 'bg-gray-300'
                  }`}
                />
              ))}
            </div>
            
            <button
              onClick={nextSlide}
              className="p-2 rounded-full bg-white shadow-lg hover:bg-gray-50 transition-colors"
            >
              <ChevronRight className="w-5 h-5 text-pazos-navy" />
            </button>
          </div>
        </div>

        {/* Services Grid para Desktop */}
        <div className="hidden lg:grid lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <div key={service.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
              <div className="relative h-64">
                <Image
                  src={service.image}
                  alt={service.imageAlt}
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                <div className="absolute top-4 left-4">
                  <service.icon className="w-10 h-10 text-pazos-yellow" />
                </div>
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="inline-block bg-pazos-yellow text-pazos-navy px-4 py-2 rounded-full text-sm font-semibold">
                    {service.subtitle}
                  </div>
                </div>
              </div>
              
              <div className="p-8">
                <h3 className="text-2xl font-bold text-pazos-navy mb-4">{service.title}</h3>
                <p className="text-gray-600 mb-6">{service.description}</p>
                
                <ul className="space-y-3 mb-6">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center text-gray-600">
                      <div className="w-2 h-2 bg-pazos-yellow rounded-full mr-3"></div>
                      {feature}
                    </li>
                  ))}
                </ul>

                <div className="bg-gray-50 rounded-lg p-4 mb-6">
                  <p className="text-sm text-gray-600 italic">{service.marketInsight}</p>
                </div>
                
                <button
                  onClick={() => handleWhatsAppClick(service.whatsappMessage)}
                  className="w-full cta-button flex items-center justify-center space-x-3 py-3 px-6 rounded-lg font-semibold transform hover:scale-105 transition-all duration-300"
                >
                  <MessageCircle size={20} />
                  <span>{service.cta}</span>
                  <ArrowRight size={18} />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Final de sección */}
        <div className="text-center mt-12">
          <div className="bg-pazos-navy rounded-xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">¿Necesitas una Combinación de Servicios?</h3>
            <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
              Muchos de nuestros clientes combinan piscinas con chalets, o domos con áreas de spa. 
              Ofrecemos paquetes integrales con descuentos especiales.
            </p>
            <button
              onClick={() => handleWhatsAppClick('Hola! Me interesa información sobre paquetes combinados de servicios (piscina + chalet, domo + spa, etc.). ¿Podrían enviarme opciones y precios especiales?')}
              className="cta-button inline-flex items-center space-x-3 py-3 px-8 rounded-lg font-semibold transform hover:scale-105 transition-all duration-300"
            >
              <MessageCircle size={20} />
              <span>Consultar Paquetes Especiales</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection; 