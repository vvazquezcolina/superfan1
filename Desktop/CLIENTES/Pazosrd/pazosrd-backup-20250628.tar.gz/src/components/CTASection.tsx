'use client';

import { MessageCircle, TrendingUp, DollarSign, Calendar, Star, ArrowRight } from 'lucide-react';

const CTASection = () => {
  const handleWhatsAppClick = (ctaType: string) => {
    let message = '';
    
    switch (ctaType) {
      case 'financiamiento':
        message = 'Hola! Me interesa conocer las opciones de financiamiento desde $200 USD mensuales para mi piscina. ¿Podrían enviarme información detallada?';
        break;
      case 'boom-turistico':
        message = 'Hola! Quiero aprovechar el boom turístico en RD para mi negocio. ¿Podrían asesorarme sobre qué proyecto (piscina, domos, chalets) sería más rentable?';
        break;
      case 'consulta-gratuita':
        message = 'Hola! Me gustaría solicitar una consulta técnica gratuita para evaluar mi proyecto y conocer las opciones disponibles.';
        break;
      case 'visita-sitio':
        message = 'Hola! ¿Podrían agendar una visita a mi propiedad para evaluar el terreno y darme una cotización personalizada?';
        break;
      default:
        message = 'Hola! Estoy listo para materializar mi proyecto con Pazos Holding. ¿Podrían contactarme para comenzar?';
    }
    
    const encodedMessage = encodeURIComponent(message);
    window.open(`https://wa.me/18492528368?text=${encodedMessage}`, '_blank');
  };

  return (
    <section id="cta" className="py-16 bg-gradient-to-r from-pazos-yellow via-yellow-400 to-pazos-yellow">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
            
            {/* Left Side - Main CTA */}
            <div className="p-8 lg:p-12 bg-pazos-navy text-white relative overflow-hidden">
              {/* Background Pattern */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-pazos-yellow opacity-10 rounded-full -mr-16 -mt-16"></div>
              <div className="absolute bottom-0 left-0 w-24 h-24 bg-pazos-yellow opacity-10 rounded-full -ml-12 -mb-12"></div>
              
              <div className="relative z-10">
                <div className="inline-flex items-center px-4 py-2 bg-pazos-yellow bg-opacity-20 rounded-full mb-6">
                  <TrendingUp className="w-4 h-4 text-pazos-yellow mr-2" />
                  <span className="text-pazos-yellow font-semibold text-sm">
                    Oportunidad Única en RD
                  </span>
                </div>
                
                <h2 className="text-3xl lg:text-4xl font-bold mb-6 leading-tight">
                  ¿Listo para Materializar
                  <span className="block text-pazos-yellow">tu Proyecto?</span>
                </h2>
                
                <div className="space-y-4 mb-8">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-pazos-yellow bg-opacity-20 rounded-full flex items-center justify-center mt-1">
                      <Star className="w-3 h-3 text-pazos-yellow" />
                    </div>
                    <div>
                      <p className="text-white font-medium">Aprovecha el Boom Turístico</p>
                      <p className="text-gray-300 text-sm">8.3M+ turistas en 2024 (+10%), ocupación hotelera 90.7%</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-pazos-yellow bg-opacity-20 rounded-full flex items-center justify-center mt-1">
                      <DollarSign className="w-3 h-3 text-pazos-yellow" />
                    </div>
                    <div>
                      <p className="text-white font-medium">Financiamiento Directo</p>
                      <p className="text-gray-300 text-sm">Piscinas desde $200 USD/mes, planes hasta 36 meses</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-pazos-yellow bg-opacity-20 rounded-full flex items-center justify-center mt-1">
                      <Calendar className="w-3 h-3 text-pazos-yellow" />
                    </div>
                    <div>
                      <p className="text-white font-medium">Construcción Rápida</p>
                      <p className="text-gray-300 text-sm">Piscinas en 6-8 semanas, domos en 3-5 días</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white bg-opacity-10 rounded-xl p-6 backdrop-blur-sm mb-8">
                  <h3 className="text-xl font-bold text-pazos-yellow mb-3">¡Oferta Especial!</h3>
                  <p className="text-white mb-4">
                    Los primeros <strong>10 clientes</strong> de cada mes reciben:
                  </p>
                  <ul className="space-y-2 text-sm text-gray-200">
                    <li className="flex items-center space-x-2">
                      <div className="w-1.5 h-1.5 bg-pazos-yellow rounded-full"></div>
                      <span>Consulta técnica y diseño 3D <strong>GRATIS</strong></span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-1.5 h-1.5 bg-pazos-yellow rounded-full"></div>
                      <span>Gestión de permisos <strong>SIN COSTO</strong></span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-1.5 h-1.5 bg-pazos-yellow rounded-full"></div>
                      <span>Financiamiento <strong>0% interés</strong> hasta 12 meses</span>
                    </li>
                  </ul>
                </div>
                
                <button
                  onClick={() => handleWhatsAppClick('consulta-gratuita')}
                  className="w-full cta-button flex items-center justify-center space-x-3 py-4 px-6 rounded-lg font-bold text-lg transform hover:scale-105 transition-all duration-300 shadow-xl"
                >
                  <MessageCircle size={24} />
                  <span>Solicitar Consulta GRATIS</span>
                  <ArrowRight size={20} />
                </button>
                
                <p className="text-center text-sm text-gray-300 mt-4">
                  * Promoción válida hasta fin de mes • Sin compromiso
                </p>
              </div>
            </div>
            
            {/* Right Side - Action Options */}
            <div className="p-8 lg:p-12 bg-gray-50">
              <h3 className="text-2xl font-bold text-pazos-navy mb-8 text-center">
                Elige tu Próximo Paso
              </h3>
              
              <div className="space-y-4">
                <button
                  onClick={() => handleWhatsAppClick('financiamiento')}
                  className="w-full bg-white hover:bg-gray-50 text-pazos-navy border-2 border-gray-200 hover:border-pazos-yellow p-6 rounded-xl transition-all duration-300 text-left group"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-lg mb-2">Conocer Financiamiento</h4>
                      <p className="text-gray-700 text-sm">Desde $200 USD/mes • 0% interés hasta 12 meses</p>
                    </div>
                    <DollarSign className="w-6 h-6 text-pazos-yellow group-hover:scale-110 transition-transform" />
                  </div>
                </button>
                
                <button
                  onClick={() => handleWhatsAppClick('boom-turistico')}
                  className="w-full bg-white hover:bg-gray-50 text-pazos-navy border-2 border-gray-200 hover:border-pazos-yellow p-6 rounded-xl transition-all duration-300 text-left group"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-lg mb-2">Invertir en Turismo</h4>
                      <p className="text-gray-700 text-sm">ROI comprobado • Aprovecha el crecimiento del 10%</p>
                    </div>
                    <TrendingUp className="w-6 h-6 text-pazos-yellow group-hover:scale-110 transition-transform" />
                  </div>
                </button>
                
                <button
                  onClick={() => handleWhatsAppClick('visita-sitio')}
                  className="w-full bg-white hover:bg-gray-50 text-pazos-navy border-2 border-gray-200 hover:border-pazos-yellow p-6 rounded-xl transition-all duration-300 text-left group"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-lg mb-2">Agendar Visita</h4>
                      <p className="text-gray-700 text-sm">Evaluación gratuita • Cotización personalizada</p>
                    </div>
                    <Calendar className="w-6 h-6 text-pazos-yellow group-hover:scale-110 transition-transform" />
                  </div>
                </button>
              </div>
              
              {/* Trust Signals */}
              <div className="mt-8 pt-8 border-t border-gray-200">
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-pazos-navy">27</div>
                            <div className="text-xs text-gray-600">Años Experiencia</div>
      </div>
      <div>
        <div className="text-2xl font-bold text-pazos-navy">5</div>
        <div className="text-xs text-gray-600">Años Garantía</div>
      </div>
      <div>
        <div className="text-2xl font-bold text-pazos-navy">100%</div>
        <div className="text-xs text-gray-600">Satisfacción</div>
                  </div>
                </div>
              </div>
              
              {/* Emergency Contact */}
              <div className="mt-8 bg-pazos-yellow bg-opacity-20 rounded-xl p-4 text-center">
                <p className="text-pazos-navy font-semibold text-sm mb-2">
                  ¿Necesitas Respuesta Inmediata?
                </p>
                <button
                  onClick={() => {
                    const message = encodeURIComponent('¡URGENTE! Necesito información inmediata sobre su servicio. Por favor contactenme lo antes posible.');
                    window.open(`https://wa.me/18492528368?text=${message}`, '_blank');
                  }}
                  className="bg-pazos-navy text-white px-4 py-2 rounded-lg font-semibold text-sm hover:bg-pazos-navy-dark transition-colors"
                >
                  Contacto Inmediato
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Bottom Stats */}
        <div className="mt-12 text-center">
          <div className="inline-flex items-center space-x-8 bg-white bg-opacity-90 rounded-full py-4 px-8 shadow-lg">
            <div className="text-center">
              <div className="text-lg font-bold text-pazos-navy">8.3M+</div>
              <div className="text-xs text-gray-600">Turistas 2024</div>
            </div>
            <div className="w-px h-8 bg-gray-300"></div>
            <div className="text-center">
              <div className="text-lg font-bold text-pazos-navy">90.7%</div>
              <div className="text-xs text-gray-600">Ocupación Hotelera</div>
            </div>
            <div className="w-px h-8 bg-gray-300"></div>
            <div className="text-center">
              <div className="text-lg font-bold text-pazos-navy">+10%</div>
              <div className="text-xs text-gray-600">Crecimiento</div>
            </div>
          </div>
          <p className="text-sm text-pazos-navy-dark mt-4 font-medium">
            El momento perfecto para invertir en República Dominicana es AHORA
          </p>
        </div>
      </div>
    </section>
  );
};

export default CTASection; 