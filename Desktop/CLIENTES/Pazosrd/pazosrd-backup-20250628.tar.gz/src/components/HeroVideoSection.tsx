'use client';

import { useState } from 'react';
import { Play, MessageCircle } from 'lucide-react';

const HeroVideoSection = () => {
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const [videoError, setVideoError] = useState(false);

  const handlePlayVideo = () => {
    setIsVideoPlaying(true);
  };

  const handleWhatsAppClick = () => {
    const message = encodeURIComponent('Hola! Me interesa solicitar una cotización para mi proyecto.');
    window.open(`https://wa.me/18492528368?text=${message}`, '_blank');
  };

  const handleScrollToContact = () => {
    const contactSection = document.getElementById('contacto');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-pazos-navy via-pazos-navy-dark to-pazos-navy">
      {/* Background Video o Imagen */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="relative w-full h-full">
          {/* Fallback gradient siempre presente */}
          <div className="absolute inset-0 bg-gradient-to-br from-pazos-navy via-pazos-navy-dark to-blue-900"></div>
          
          {/* Video Background */}
          {!videoError && (
            <div className="absolute inset-0">
              {isVideoPlaying ? (
                <iframe
                  src="https://player.vimeo.com/video/1051259867?h=fc0f3fa380&autoplay=1&loop=1&muted=1&background=1&controls=0&title=0&byline=0&portrait=0"
                  className="absolute top-0 left-0 w-full h-full"
                  style={{ 
                    width: '100vw', 
                    height: '100vh',
                    objectFit: 'cover',
                    pointerEvents: 'none'
                  }}
                  frameBorder="0"
                  allow="autoplay; fullscreen; picture-in-picture"
                  allowFullScreen
                  title="Pazos Holding - Video Corporativo"
                  onError={() => setVideoError(true)}
                />
              ) : (
                // Thumbnail del video con botón de play
                <div 
                  className="absolute inset-0 bg-cover bg-center cursor-pointer group"
                  style={{
                    backgroundImage: `linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.3)), url('https://i.vimeocdn.com/video/1051259867_1920x1080.jpg?r=pad_360')`
                  }}
                  onClick={handlePlayVideo}
                >
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="bg-white bg-opacity-20 backdrop-blur-sm rounded-full p-6 group-hover:bg-opacity-30 transition-all duration-300 group-hover:scale-110">
                      <Play size={48} className="text-white ml-2" />
                    </div>
                  </div>
                  <div className="absolute bottom-6 left-6 text-white">
                    <p className="text-sm opacity-80">Click para reproducir video</p>
                  </div>
                </div>
              )}
            </div>
          )}
          
          {/* Overlay para legibilidad */}
          <div className="absolute inset-0 bg-black bg-opacity-40"></div>
        </div>
      </div>

      {/* Hero Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="max-w-4xl mx-auto">
          {/* New in DR Badge */}
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-pazos-yellow bg-opacity-20 border border-pazos-yellow mb-6 animate-fade-in">
            <span className="text-pazos-yellow font-semibold text-sm sm:text-base">
              ¡Nuevo en RD!
            </span>
          </div>

          {/* Main Title */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold text-white mb-6 leading-tight animate-slide-up">
            Construcción
            <span className="block text-pazos-yellow">Personalizada</span>
            <span className="block text-2xl sm:text-3xl lg:text-4xl xl:text-5xl font-normal mt-2">
              con 27 años de experiencia
            </span>
          </h1>

          {/* Subtitle */}
          <p className="text-lg sm:text-xl lg:text-2xl text-gray-200 mb-8 max-w-3xl mx-auto leading-relaxed animate-slide-up" style={{ animationDelay: '0.2s' }}>
            Calidad, Innovación y Satisfacción Garantizada en cada proyecto
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center animate-slide-up" style={{ animationDelay: '0.4s' }}>
            {/* Primary CTA */}
            <button
              onClick={handleWhatsAppClick}
              className="cta-button w-full sm:w-auto flex items-center justify-center space-x-3 px-8 py-4 text-lg font-bold rounded-lg shadow-2xl transform hover:scale-105 transition-all duration-300"
            >
              <MessageCircle size={24} />
              <span>Solicita Cotización Ahora</span>
            </button>

            {/* Secondary CTA */}
            <button
              onClick={handleScrollToContact}
              className="w-full sm:w-auto bg-transparent border-2 border-white text-white hover:bg-white hover:text-pazos-navy px-8 py-4 text-lg font-semibold rounded-lg transition-all duration-300 flex items-center justify-center space-x-3"
            >
              <Play size={20} />
              <span>Ver Proyectos</span>
            </button>
          </div>

          {/* Trust Indicators */}
          <div className="mt-12 grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-2xl mx-auto animate-slide-up" style={{ animationDelay: '0.6s' }}>
            <div className="text-center">
              <div className="text-3xl font-bold text-pazos-yellow mb-1">27+</div>
              <div className="text-sm text-gray-300">Años de Experiencia</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-pazos-yellow mb-1">500+</div>
              <div className="text-sm text-gray-300">Proyectos Completados</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-pazos-yellow mb-1">100%</div>
              <div className="text-sm text-gray-300">Satisfacción Garantizada</div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10">
        <div className="animate-bounce-gentle">
          <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
            <div className="w-1 h-3 bg-white rounded-full mt-2 animate-pulse"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroVideoSection; 