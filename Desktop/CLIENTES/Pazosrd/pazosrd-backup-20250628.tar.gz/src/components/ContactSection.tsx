'use client';

import { useState } from 'react';
import { 
  MessageCircle, 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  Send,
  Facebook,
  Instagram,
  Youtube,
  Award,
  Shield,
  Star,
  Users,
  Building,
  Briefcase
} from 'lucide-react';

const ContactSection = () => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    service: '',
    message: '',
    budget: '',
    timeline: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const whatsappMessage = `
🏗️ *NUEVA CONSULTA - PAZOS HOLDING*

👤 *Cliente:* ${formData.name}
📱 *Teléfono:* ${formData.phone}
✉️ *Email:* ${formData.email}

🏊 *Servicio de Interés:* ${formData.service}
💰 *Presupuesto Estimado:* ${formData.budget}
📅 *Tiempo Deseado:* ${formData.timeline}

💬 *Mensaje:*
${formData.message}

---
*Enviado desde pazosholding.com*
    `.trim();

    const encodedMessage = encodeURIComponent(whatsappMessage);
    window.open(`https://wa.me/18492528368?text=${encodedMessage}`, '_blank');
    
    // Reset form
    setFormData({
      name: '',
      phone: '',
      email: '',
      service: '',
      message: '',
      budget: '',
      timeline: ''
    });
  };

  const handleDirectWhatsApp = (type: string) => {
    let message = '';
    
    switch (type) {
      case 'emergency':
        message = '🚨 URGENTE: Necesito cotización inmediata para mi proyecto. Por favor contactarme lo antes posible.';
        break;
      case 'visit':
        message = '🏠 Me gustaría agendar una visita técnica gratuita a mi propiedad para evaluación y cotización personalizada.';
        break;
      case 'financing':
        message = '💳 Quiero información detallada sobre financiamiento desde $200 USD/mes y planes de pago disponibles.';
        break;
      default:
        message = '👋 Hola! Me interesa conocer más sobre los servicios de Pazos Holding en República Dominicana.';
    }
    
    const encodedMessage = encodeURIComponent(message);
    window.open(`https://wa.me/18492528368?text=${encodedMessage}`, '_blank');
  };

  return (
    <section id="contacto" className="py-16 bg-gradient-to-br from-pazos-navy to-pazos-navy-dark">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-pazos-yellow bg-opacity-20 border border-pazos-yellow mb-4">
            <span className="text-pazos-yellow font-semibold text-sm">
              📞 Estamos Listos para Ayudarte
            </span>
          </div>
          
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Hablemos de tu
            <span className="block text-pazos-yellow">Proyecto Hoy</span>
          </h2>
          
          <p className="text-lg text-gray-300 max-w-3xl mx-auto">
            Con <strong>27 años de experiencia</strong>, estamos preparados para hacer realidad 
            tu proyecto en República Dominicana. Contáctanos ahora.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Contact Form */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl p-8 shadow-2xl">
              <h3 className="text-2xl font-bold text-pazos-navy mb-6">Cotiza tu Proyecto Gratis</h3>
              
              <form onSubmit={handleFormSubmit} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-semibold text-pazos-navy mb-2">
                      Nombre Completo *
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pazos-yellow focus:border-transparent"
                      placeholder="Tu nombre completo"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="phone" className="block text-sm font-semibold text-pazos-navy mb-2">
                      WhatsApp / Teléfono *
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pazos-yellow focus:border-transparent"
                      placeholder="+1 (809) 123-4567"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-semibold text-pazos-navy mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pazos-yellow focus:border-transparent"
                    placeholder="tu@email.com"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="service" className="block text-sm font-semibold text-pazos-navy mb-2">
                      Servicio de Interés *
                    </label>
                    <select
                      id="service"
                      name="service"
                      value={formData.service}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pazos-yellow focus:border-transparent"
                    >
                      <option value="">Selecciona un servicio</option>
                      <option value="Piscinas & Jacuzzis">Piscinas & Jacuzzis</option>
                      <option value="Domos Geodésicos">Domos Geodésicos</option>
                      <option value="Chalets Enchante">Chalets Enchante</option>
                      <option value="Proyecto Combinado">Proyecto Combinado</option>
                      <option value="Remodelaciones">Remodelaciones</option>
                      <option value="Consultoría">Consultoría</option>
                    </select>
                  </div>
                  
                  <div>
                    <label htmlFor="budget" className="block text-sm font-semibold text-pazos-navy mb-2">
                      Presupuesto Estimado
                    </label>
                    <select
                      id="budget"
                      name="budget"
                      value={formData.budget}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pazos-yellow focus:border-transparent"
                    >
                      <option value="">Selecciona rango</option>
                      <option value="$15,000 - $30,000 USD">$15,000 - $30,000 USD</option>
                      <option value="$30,000 - $50,000 USD">$30,000 - $50,000 USD</option>
                      <option value="$50,000 - $100,000 USD">$50,000 - $100,000 USD</option>
                      <option value="$100,000 - $200,000 USD">$100,000 - $200,000 USD</option>
                      <option value="$200,000+ USD">$200,000+ USD</option>
                      <option value="Por definir">Por definir</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label htmlFor="timeline" className="block text-sm font-semibold text-pazos-navy mb-2">
                    ¿Cuándo te gustaría comenzar?
                  </label>
                  <select
                    id="timeline"
                    name="timeline"
                    value={formData.timeline}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pazos-yellow focus:border-transparent"
                  >
                    <option value="">Selecciona tiempo</option>
                    <option value="Inmediatamente">Inmediatamente</option>
                    <option value="En las próximas 4 semanas">En las próximas 4 semanas</option>
                    <option value="En 2-3 meses">En 2-3 meses</option>
                    <option value="En 6 meses">En 6 meses</option>
                    <option value="Solo estoy investigando">Solo estoy investigando</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-semibold text-pazos-navy mb-2">
                    Cuéntanos sobre tu proyecto
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    rows={4}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pazos-yellow focus:border-transparent resize-none"
                    placeholder="Describe tu proyecto, ubicación, ideas específicas, etc."
                  />
                </div>

                <button
                  type="submit"
                  className="w-full cta-button flex items-center justify-center space-x-3 py-4 px-6 rounded-lg font-bold text-lg transform hover:scale-105 transition-all duration-300 shadow-xl"
                >
                  <Send size={24} />
                  <span>Enviar a WhatsApp</span>
                </button>
                
                <p className="text-center text-sm text-gray-600">
                  * Al enviar, serás redirigido a WhatsApp con tu información pre-cargada
                </p>
              </form>
            </div>
          </div>

          {/* Contact Info & Quick Actions */}
          <div className="space-y-6">
            
            {/* Direct Contact */}
            <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-2xl p-6 text-white">
              <h3 className="text-xl font-bold mb-6">Contacto Directo</h3>
              
              <div className="space-y-4">
                <a 
                  href="https://wa.me/18492528368"
                  className="flex items-center space-x-3 p-3 bg-pazos-whatsapp hover:bg-green-600 rounded-lg transition-colors"
                >
                  <MessageCircle className="w-5 h-5" />
                  <div>
                    <div className="font-semibold">WhatsApp</div>
                    <div className="text-sm">+1 (849) 252-8368</div>
                  </div>
                </a>
                
                <a 
                  href="tel:+18492528368"
                  className="flex items-center space-x-3 p-3 bg-white bg-opacity-20 hover:bg-opacity-30 rounded-lg transition-colors"
                >
                  <Phone className="w-5 h-5" />
                  <div>
                    <div className="font-semibold">Teléfono</div>
                    <div className="text-sm">+1 (849) 252-8368</div>
                  </div>
                </a>
                
                <a 
                  href="mailto:info@pazosholding.com"
                  className="flex items-center space-x-3 p-3 bg-white bg-opacity-20 hover:bg-opacity-30 rounded-lg transition-colors"
                >
                  <Mail className="w-5 h-5" />
                  <div>
                    <div className="font-semibold">Email</div>
                    <div className="text-sm">info@pazosholding.com</div>
                  </div>
                </a>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-2xl p-6 text-white">
              <h3 className="text-xl font-bold mb-6">Acciones Rápidas</h3>
              
              <div className="space-y-3">
                <button
                  onClick={() => handleDirectWhatsApp('emergency')}
                  className="w-full bg-red-600 hover:bg-red-700 text-white p-3 rounded-lg font-semibold transition-colors text-left"
                >
                  🚨 Cotización Urgente
                </button>
                
                <button
                  onClick={() => handleDirectWhatsApp('visit')}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-lg font-semibold transition-colors text-left"
                >
                  🏠 Agendar Visita Técnica
                </button>
                
                <button
                  onClick={() => handleDirectWhatsApp('financing')}
                  className="w-full bg-green-600 hover:bg-green-700 text-white p-3 rounded-lg font-semibold transition-colors text-left"
                >
                  💳 Info de Financiamiento
                </button>
              </div>
            </div>

            {/* Office Hours */}
            <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-2xl p-6 text-white">
              <h3 className="text-xl font-bold mb-4">Horarios de Atención</h3>
              
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Clock className="w-5 h-5 text-pazos-yellow" />
                  <div>
                    <div className="font-semibold">Lun - Vie: 8:00 AM - 6:00 PM</div>
                    <div className="text-sm text-gray-300">Sábados: 9:00 AM - 2:00 PM</div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <MapPin className="w-5 h-5 text-pazos-yellow" />
                  <div>
                    <div className="font-semibold">Punta Cana, República Dominicana</div>
                    <div className="text-sm text-gray-300">Servicio en todo el país</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Trust Badges */}
            <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-2xl p-6 text-white">
              <div className="grid grid-cols-2 gap-4 text-center">
                <div>
                  <Award className="w-8 h-8 text-pazos-yellow mx-auto mb-2" />
                  <div className="text-2xl font-bold">27</div>
                  <div className="text-xs">Años Experiencia</div>
                </div>
                <div>
                  <Shield className="w-8 h-8 text-pazos-yellow mx-auto mb-2" />
                  <div className="text-2xl font-bold">5</div>
                  <div className="text-xs">Años Garantía</div>
                </div>
                <div>
                  <Star className="w-8 h-8 text-pazos-yellow mx-auto mb-2" />
                  <div className="text-2xl font-bold">100%</div>
                  <div className="text-xs">Satisfacción</div>
                </div>
                <div>
                  <Users className="w-8 h-8 text-pazos-yellow mx-auto mb-2" />
                  <div className="text-2xl font-bold">500+</div>
                  <div className="text-xs">Proyectos</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <footer className="mt-16 pt-12 border-t border-white border-opacity-20">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
            
            {/* Company Info */}
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <Building className="w-8 h-8 text-pazos-yellow" />
                <div>
                  <h3 className="text-xl font-bold text-white">PazosRD</h3>
                  <p className="text-sm text-gray-300">Pazos Holding</p>
                </div>
              </div>
              <p className="text-gray-300 text-sm leading-relaxed">
                Empresa mexicana líder en construcción especializada, 
                ahora en República Dominicana con 27 años de experiencia internacional.
              </p>
            </div>

            {/* Services */}
            <div>
              <h4 className="text-lg font-semibold text-white mb-4">Servicios</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li><a href="#servicios" className="hover:text-pazos-yellow transition-colors">Piscinas & Jacuzzis</a></li>
                <li><a href="#servicios" className="hover:text-pazos-yellow transition-colors">Domos Geodésicos</a></li>
                <li><a href="#servicios" className="hover:text-pazos-yellow transition-colors">Chalets Enchante</a></li>
                <li><a href="#servicios" className="hover:text-pazos-yellow transition-colors">Proyectos Combinados</a></li>
                <li><a href="#servicios" className="hover:text-pazos-yellow transition-colors">Remodelaciones</a></li>
              </ul>
            </div>

            {/* Company */}
            <div>
              <h4 className="text-lg font-semibold text-white mb-4">Empresa</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li><a href="#confianza" className="hover:text-pazos-yellow transition-colors">¿Quiénes Somos?</a></li>
                <li><a href="#proyectos" className="hover:text-pazos-yellow transition-colors">Proyectos</a></li>
                <li><a href="#faq" className="hover:text-pazos-yellow transition-colors">Preguntas Frecuentes</a></li>
                <li><a href="#contacto" className="hover:text-pazos-yellow transition-colors">Contacto</a></li>
                <li><a href="#" className="hover:text-pazos-yellow transition-colors">Garantías</a></li>
              </ul>
            </div>

            {/* Legal & Social */}
            <div>
              <h4 className="text-lg font-semibold text-white mb-4">Síguenos</h4>
              <div className="flex space-x-4 mb-4">
                <a href="#" className="w-10 h-10 bg-white bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 transition-colors">
                  <Facebook className="w-5 h-5 text-white" />
                </a>
                <a href="#" className="w-10 h-10 bg-white bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 transition-colors">
                  <Instagram className="w-5 h-5 text-white" />
                </a>
                <a href="#" className="w-10 h-10 bg-white bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 transition-colors">
                  <Youtube className="w-5 h-5 text-white" />
                </a>
              </div>
              <ul className="space-y-2 text-sm text-gray-300">
                <li><a href="#" className="hover:text-pazos-yellow transition-colors">Política de Privacidad</a></li>
                <li><a href="#" className="hover:text-pazos-yellow transition-colors">Términos de Servicio</a></li>
              </ul>
            </div>
          </div>

          {/* Copyright */}
          <div className="pt-8 border-t border-white border-opacity-20 text-center">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <p className="text-sm text-gray-300">
                © 2024 Pazos Holding. Todos los derechos reservados.
              </p>
              <div className="flex items-center space-x-2 mt-4 md:mt-0">
                <Briefcase className="w-4 h-4 text-pazos-yellow" />
                <span className="text-sm text-gray-300">
                  Construyendo el futuro de República Dominicana desde 1997
                </span>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </section>
  );
};

export default ContactSection; 