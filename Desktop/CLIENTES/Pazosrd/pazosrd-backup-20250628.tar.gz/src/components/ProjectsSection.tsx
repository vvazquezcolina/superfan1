'use client';

import { useState } from 'react';
import { ChevronLeft, ChevronRight, MapPin, Calendar, DollarSign, Users, Star, MessageCircle, TrendingUp } from 'lucide-react';
import Image from 'next/image';

const ProjectsSection = () => {
  const [currentProject, setCurrentProject] = useState(0);

  const projects = [
    {
      id: 'piscina-punta-cana',
      title: 'Piscina Infinity • Resort Punta Cana',
      category: 'Piscinas & Jacuzzis',
      location: 'Punta Cana, República Dominicana',
      year: '2024',
      duration: '6 semanas',
      investment: '$85,000 USD',
      roi: 'Ocupación +15%',
      image: '/images/render de piscina.webp',
      description: 'Piscina infinity de 15 metros con sistema de filtrado avanzado y área de jacuzzi integrada. Diseñada para maximizar la experiencia de huéspedes en resort boutique.',
      features: [
        'Piscina infinity con vista al mar',
        'Sistema de filtrado alemán Pentair',
        'Jacuzzi integrado para 8 personas',
        'Iluminación LED subacuática RGB',
        'Sistema de calefacción solar'
      ],
      results: [
        'Incremento de ocupación del 15%',
        'Aumento de tarifa promedio $50/noche',
        'ROI del 180% en primer año',
        'Calificación de huéspedes: 4.9/5'
      ],
      testimonial: {
        text: "Pazos Holding transformó nuestro resort. La piscina infinity se convirtió en el punto focal que nuestros huéspedes más fotografían. El incremento en reservas fue inmediato.",
        author: "Carlos Méndez",
        role: "Gerente General, Punta Cana Beach Resort",
        rating: 5
      }
    },
    {
      id: 'domos-jarabacoa',
      title: 'Domos Glamping • Eco-Lodge Jarabacoa',
      category: 'Domos Geodésicos',
      location: 'Jarabacoa, República Dominicana',
      year: '2024',
      duration: '3 semanas',
      investment: '$120,000 USD',
      roi: 'ROI 300% año 1',
      image: '/images/Render de Geodésica.webp',
      description: '5 domos geodésicos ecológicos con vista a las montañas. Cada domo cuenta con baño privado, aire acondicionado y terraza panorámica.',
      features: [
        '5 domos de 35m² cada uno',
        'Estructura anti-huracanes certificada',
        'Materiales eco-friendly importados',
        'Baño privado y aire acondicionado',
        'Terraza panorámica con vista montañas'
      ],
      results: [
        'ROI del 300% en primer año',
        'Ocupación promedio 85%',
        'Tarifa promedio $180/noche',
        'Reconocimiento turismo sostenible'
      ],
      testimonial: {
        text: "Los domos geodésicos de Pazos fueron la mejor inversión. Nuestros huéspedes vienen específicamente por la experiencia única. Estamos expandiendo con 5 domos más.",
        author: "María Rodríguez",
        role: "Propietaria, Mountain View Eco-Lodge",
        rating: 5
      }
    },
    {
      id: 'chalets-santo-domingo',
      title: 'Chalets Enchante • Villa Familiar',
      category: 'Chalets de Lujo',
      location: 'Santo Domingo, República Dominicana',
      year: '2024',
      duration: '4 semanas',
      investment: '$75,000 USD',
      roi: '40% ahorro vs tradicional',
      image: '/images/Render Chalet.webp',
      description: 'Chalet familiar de 120m² con 3 habitaciones, diseño personalizado y acabados de lujo. Construido en tiempo récord sin comprometer calidad.',
      features: [
        'Chalet de 120m² con 3 habitaciones',
        'Diseño arquitectónico personalizado',
        'Acabados de lujo importados',
        'Sistema domótico integrado',
        'Terraza con vista panorámica'
      ],
      results: [
        '40% ahorro vs construcción tradicional',
        'Entrega en tiempo récord',
        'Valorización inmediata +25%',
        'Cero defectos post-entrega'
      ],
      testimonial: {
        text: "Pazos Holding nos entregó exactamente lo que soñábamos, pero en la mitad del tiempo esperado. La calidad es impecable y el ahorro fue significativo.",
        author: "Roberto Vásquez",
        role: "Propietario, Villa Los Almendros",
        rating: 5
      }
    },
    {
      id: 'combo-resort-sosua',
      title: 'Proyecto Integral • Resort Sosúa',
      category: 'Paquete Completo',
      location: 'Sosúa, República Dominicana',
      year: '2024',
      duration: '10 semanas',
      investment: '$280,000 USD',
      roi: 'Ocupación 90.7%',
      image: '/images/Render Jacuzzi.webp',
      description: 'Proyecto integral combinando piscina central, 3 domos glamping y 2 chalets VIP. Diseño cohesivo que maximiza la experiencia del huésped.',
      features: [
        'Piscina central con jacuzzi',
        '3 domos glamping premium',
        '2 chalets VIP con vista al mar',
        'Área de spa y relajación',
        'Paisajismo tropical completo'
      ],
      results: [
        'Ocupación del 90.7% temporada alta',
        'Tarifa promedio $220/noche',
        'Reconocimiento TripAdvisor',
        'Expansión programada 2025'
      ],
      testimonial: {
        text: "Pazos Holding logró integrar todos nuestros servicios en un concepto único. Somos el resort más solicitado de Sosúa gracias a su visión integral.",
        author: "Ana Martínez",
        role: "Directora, Sosúa Paradise Resort",
        rating: 5
      }
    }
  ];

  const nextProject = () => {
    setCurrentProject((prev) => (prev + 1) % projects.length);
  };

  const prevProject = () => {
    setCurrentProject((prev) => (prev - 1 + projects.length) % projects.length);
  };

  const handleWhatsAppClick = (projectType: string) => {
    const message = encodeURIComponent(`Hola! Vi el proyecto de ${projectType} y me interesa algo similar. ¿Podrían enviarme información sobre cómo replicar este éxito en mi propiedad/negocio?`);
    window.open(`https://wa.me/18492528368?text=${message}`, '_blank');
  };

  return (
    <section id="proyectos" className="py-16 bg-gradient-to-br from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-pazos-yellow bg-opacity-20 border border-pazos-yellow mb-4">
            <span className="text-pazos-navy font-semibold text-sm">
              🏆 Casos de Éxito Comprobados
            </span>
          </div>
          
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-pazos-navy mb-4">
            Proyectos que Generan
            <span className="block text-pazos-yellow">Resultados Reales</span>
          </h2>
          
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Descubre cómo nuestros clientes han transformado sus inversiones en 
            <strong> experiencias únicas y rentables</strong> en el mercado dominicano.
          </p>
        </div>

        {/* Project Showcase */}
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
            {/* Project Image */}
            <div className="relative h-64 lg:h-auto">
              <Image
                src={projects[currentProject].image}
                alt={projects[currentProject].title}
                fill
                className="object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent lg:bg-gradient-to-r lg:from-transparent lg:to-black/30"></div>
              
              {/* Category Badge */}
              <div className="absolute top-4 left-4">
                <div className="bg-pazos-yellow text-pazos-navy px-4 py-2 rounded-full font-semibold text-sm">
                  {projects[currentProject].category}
                </div>
              </div>

              {/* Navigation Controls */}
              <div className="absolute bottom-4 right-4 flex space-x-2">
                <button
                  onClick={prevProject}
                  className="p-2 bg-white bg-opacity-90 rounded-full hover:bg-opacity-100 transition-all"
                  aria-label="Proyecto anterior"
                >
                  <ChevronLeft className="w-5 h-5 text-pazos-navy" />
                </button>
                <button
                  onClick={nextProject}
                  className="p-2 bg-white bg-opacity-90 rounded-full hover:bg-opacity-100 transition-all"
                  aria-label="Siguiente proyecto"
                >
                  <ChevronRight className="w-5 h-5 text-pazos-navy" />
                </button>
              </div>
            </div>

            {/* Project Details */}
            <div className="p-8 lg:p-12">
              <h3 className="text-2xl lg:text-3xl font-bold text-pazos-navy mb-4">
                {projects[currentProject].title}
              </h3>
              
              <p className="text-gray-600 mb-6 leading-relaxed">
                {projects[currentProject].description}
              </p>

              {/* Project Stats */}
              <div className="grid grid-cols-2 gap-4 mb-8">
                <div className="flex items-center space-x-3">
                  <MapPin className="w-5 h-5 text-pazos-yellow" />
                  <div>
                    <div className="text-sm text-gray-500">Ubicación</div>
                    <div className="font-semibold text-pazos-navy">{projects[currentProject].location}</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Calendar className="w-5 h-5 text-pazos-yellow" />
                  <div>
                    <div className="text-sm text-gray-500">Duración</div>
                    <div className="font-semibold text-pazos-navy">{projects[currentProject].duration}</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <DollarSign className="w-5 h-5 text-pazos-yellow" />
                  <div>
                    <div className="text-sm text-gray-500">Inversión</div>
                    <div className="font-semibold text-pazos-navy">{projects[currentProject].investment}</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <TrendingUp className="w-5 h-5 text-pazos-yellow" />
                  <div>
                    <div className="text-sm text-gray-500">Resultado</div>
                    <div className="font-semibold text-pazos-navy">{projects[currentProject].roi}</div>
                  </div>
                </div>
              </div>

              {/* Features Grid */}
              <div className="mb-8">
                <h4 className="font-semibold text-pazos-navy mb-4">Características Principales:</h4>
                <div className="grid grid-cols-1 gap-2">
                  {projects[currentProject].features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-pazos-yellow rounded-full"></div>
                      <span className="text-gray-700 text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* CTA Button */}
              <button
                onClick={() => handleWhatsAppClick(projects[currentProject].category)}
                className="w-full cta-button flex items-center justify-center space-x-3 py-3 px-6 rounded-lg font-semibold transform hover:scale-105 transition-all duration-300"
              >
                <MessageCircle size={20} />
                <span>Solicitar Proyecto Similar</span>
              </button>
            </div>
          </div>
        </div>

        {/* Results Section */}
        <div className="mt-12 bg-pazos-navy rounded-2xl p-8 lg:p-12 text-white">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold mb-6">Resultados Medibles</h3>
              <div className="space-y-4">
                {projects[currentProject].results.map((result, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-pazos-yellow bg-opacity-20 rounded-full flex items-center justify-center">
                      <TrendingUp className="w-4 h-4 text-pazos-yellow" />
                    </div>
                    <span className="text-gray-200">{result}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white bg-opacity-10 rounded-xl p-6 backdrop-blur-sm">
              <div className="flex items-center mb-4">
                {[...Array(projects[currentProject].testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-pazos-yellow text-pazos-yellow" />
                ))}
              </div>
                             <blockquote className="text-gray-200 italic mb-4">
                 &ldquo;{projects[currentProject].testimonial.text}&rdquo;
               </blockquote>
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-pazos-yellow bg-opacity-20 rounded-full flex items-center justify-center">
                  <Users className="w-6 h-6 text-pazos-yellow" />
                </div>
                <div>
                  <div className="font-semibold text-white">{projects[currentProject].testimonial.author}</div>
                  <div className="text-sm text-gray-300">{projects[currentProject].testimonial.role}</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Project Indicators */}
        <div className="flex justify-center mt-8 space-x-2">
          {projects.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentProject(index)}
              className={`w-3 h-3 rounded-full transition-all ${
                index === currentProject ? 'bg-pazos-yellow' : 'bg-gray-300'
              }`}
              aria-label={`Ver proyecto ${index + 1}`}
            />
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-12">
          <div className="bg-gradient-to-r from-pazos-yellow to-yellow-400 rounded-xl p-8 text-pazos-navy">
            <h3 className="text-2xl font-bold mb-4">¿Listo para tu Próximo Éxito?</h3>
            <p className="text-pazos-navy-dark mb-6 max-w-2xl mx-auto">
              Cada proyecto que construimos está diseñado para generar resultados medibles. 
              Tu inversión se traduce en experiencias únicas y retornos comprobados.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => handleWhatsAppClick('consulta personalizada')}
                className="bg-pazos-navy text-white px-8 py-3 rounded-lg font-semibold hover:bg-pazos-navy-dark transition-colors"
              >
                Consulta Personalizada
              </button>
              <button
                onClick={() => {
                  const message = encodeURIComponent('Hola! Me gustaría agendar una visita para conocer proyectos similares en la zona y discutir mi proyecto.');
                  window.open(`https://wa.me/18492528368?text=${message}`, '_blank');
                }}
                className="bg-transparent border-2 border-pazos-navy text-pazos-navy px-8 py-3 rounded-lg font-semibold hover:bg-pazos-navy hover:text-white transition-colors"
              >
                Agendar Visita
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection; 