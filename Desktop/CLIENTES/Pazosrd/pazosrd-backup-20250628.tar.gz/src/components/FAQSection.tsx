'use client';

import { useState } from 'react';
import { ChevronDown, ChevronUp, MessageCircle, Clock, DollarSign, Shield, FileText, Wrench, Leaf } from 'lucide-react';

const FAQSection = () => {
  const [openFAQ, setOpenFAQ] = useState<number | null>(0);

  const toggleFAQ = (index: number) => {
    setOpenFAQ(openFAQ === index ? null : index);
  };

  const handleWhatsAppClick = (topic: string) => {
    const message = encodeURIComponent(`Hola! Tengo una pregunta específica sobre ${topic}. ¿Podrían ayudarme con más detalles?`);
    window.open(`https://wa.me/18492528368?text=${message}`, '_blank');
  };

  const faqs = [
    {
      id: 1,
      icon: Clock,
      question: "¿Cuánto tiempo tarda construir una piscina de concreto?",
      answer: "Una piscina estándar de concreto toma entre 6-8 semanas desde el inicio hasta la entrega final. Esto incluye: excavación, estructura, instalación de tuberías, aplicación de concreto, instalación de equipos, y acabados. Los factores que pueden influir en el tiempo son: tamaño del proyecto, complejidad del diseño, permisos municipales, y condiciones climáticas. En República Dominicana, planificamos considerando la temporada de lluvias para asegurar que cumplimos con los plazos acordados.",
      details: [
        "Semana 1-2: Excavación y estructura",
        "Semana 3-4: Instalación de tuberías y concreto",
        "Semana 5-6: Equipos y sistemas de filtrado",
        "Semana 7-8: Acabados y pruebas finales"
      ]
    },
    {
      id: 2,
      icon: DollarSign,
      question: "¿Ofrecen financiamiento o pagos a plazo?",
      answer: "Sí, ofrecemos planes de financiamiento directo sin intermediarios bancarios. Nuestras piscinas pueden financiarse desde $200 USD mensuales dependiendo del tamaño y características. También ofrecemos planes personalizados para domos y chalets. El financiamiento incluye: 0% interés en pagos hasta 12 meses, planes extendidos hasta 36 meses con tasas competitivas, y posibilidad de combinar múltiples servicios en un solo plan.",
      details: [
        "Piscinas básicas: Desde $200 USD/mes",
        "Financiamiento 0% hasta 12 meses",
        "Planes extendidos hasta 36 meses",
        "Sin intermediarios bancarios"
      ]
    },
    {
      id: 3,
      icon: Shield,
      question: "¿Qué garantías ofrecen en sus construcciones?",
      answer: "Ofrecemos garantía estructural completa de 5 años en todas nuestras construcciones. Esto cubre: estructura de concreto, sistemas de filtrado, impermeabilización, y defectos de construcción. Para domos geodésicos, garantizamos resistencia anti-huracanes según estándares internacionales. Además, incluimos 1 año de soporte técnico gratuito, servicio de mantenimiento opcional, y respuesta inmediata ante cualquier problema.",
      details: [
        "5 años garantía estructural completa",
        "1 año soporte técnico gratuito",
        "Cobertura de defectos de construcción",
        "Garantía de resistencia anti-huracanes"
      ]
    },
    {
      id: 4,
      icon: FileText,
      question: "¿Requiere permisos especiales una piscina o un domo?",
      answer: "Sí, pero nosotros nos encargamos de todos los trámites. En República Dominicana se requieren permisos municipales para piscinas y estructuras. Para piscinas: permiso de construcción municipal, certificado de uso de suelo, y inspección de seguridad. Para domos: permiso de estructura temporal/permanente, certificado anti-ciclónico, y aprobación ambiental si aplica. Nuestro equipo gestiona todo el proceso sin que el cliente tenga que preocuparse por la burocracia.",
      details: [
        "Gestión completa de permisos municipales",
        "Certificados de uso de suelo",
        "Inspecciones de seguridad",
        "Aprobaciones ambientales cuando aplica"
      ]
    },
    {
      id: 5,
      icon: Wrench,
      question: "¿Brindan mantenimiento después de la construcción?",
      answer: "Sí, ofrecemos paquetes de mantenimiento post-construcción. Para piscinas incluimos: limpieza semanal, balanceo químico, revisión de equipos, y mantenimiento preventivo. Para domos y chalets: inspección anual, mantenimiento de estructuras, y reparaciones menores. En clima tropical como el dominicano, el mantenimiento adecuado es crucial para la durabilidad. Nuestros técnicos conocen las condiciones locales y usan productos específicos para el Caribe.",
      details: [
        "Paquetes de mantenimiento mensual",
        "Limpieza y balanceo químico",
        "Revisión preventiva de equipos",
        "Respuesta rápida a emergencias"
      ]
    },
    {
      id: 6,
      icon: Leaf,
      question: "¿Cómo transportan e instalan un domo geodésico?",
      answer: "Los domos geodésicos se transportan en piezas modulares que se ensamblan en sitio. El proceso incluye: diseño 3D personalizado, fabricación de piezas en nuestro taller, transporte en contenedores, y montaje rápido in-situ. Un domo estándar se instala en 3-5 días con nuestro equipo especializado. Las piezas están numeradas y el ensamblaje sigue un sistema preciso. Incluimos todos los materiales, herramientas, y equipo necesario para el montaje completo.",
      details: [
        "Piezas modulares prefabricadas",
        "Transporte en contenedores",
        "Montaje in-situ en 3-5 días",
        "Sistema de ensamblaje numerado"
      ]
    }
  ];

  return (
    <section id="faq" className="py-16 bg-gradient-to-br from-gray-50 to-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-pazos-yellow bg-opacity-20 border border-pazos-yellow mb-4">
            <span className="text-pazos-navy font-semibold text-sm">
              💡 Resolvemos tus Dudas
            </span>
          </div>
          
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-pazos-navy mb-4">
            Preguntas
            <span className="block text-pazos-yellow">Frecuentes</span>
          </h2>
          
          <p className="text-lg text-gray-700 max-w-2xl mx-auto">
            Respondemos las preguntas más comunes sobre nuestros servicios, 
            procesos y garantías para que tengas total tranquilidad.
          </p>
        </div>

        {/* FAQ List */}
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div key={faq.id} className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
              <button
                onClick={() => toggleFAQ(index)}
                className="w-full px-6 py-6 text-left flex items-center justify-between hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center space-x-4">
                  <div className="p-2 bg-pazos-yellow bg-opacity-20 rounded-full">
                    <faq.icon className="w-5 h-5 text-pazos-navy" />
                  </div>
                  <h3 className="text-lg font-semibold text-pazos-navy pr-4">
                    {faq.question}
                  </h3>
                </div>
                <div className="flex-shrink-0">
                  {openFAQ === index ? (
                    <ChevronUp className="w-5 h-5 text-pazos-navy" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-pazos-navy" />
                  )}
                </div>
              </button>
              
              {openFAQ === index && (
                <div className="px-6 pb-6 border-t border-gray-100">
                  <div className="pt-6">
                    <p className="text-gray-600 leading-relaxed mb-6">
                      {faq.answer}
                    </p>
                    
                    {faq.details && (
                      <div className="bg-gray-50 rounded-lg p-4 mb-4">
                        <h4 className="font-semibold text-pazos-navy mb-3">Detalles:</h4>
                        <ul className="space-y-2">
                          {faq.details.map((detail, idx) => (
                            <li key={idx} className="flex items-center space-x-3">
                              <div className="w-2 h-2 bg-pazos-yellow rounded-full"></div>
                              <span className="text-sm text-gray-600">{detail}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                    
                    <button
                      onClick={() => handleWhatsAppClick(faq.question)}
                      className="inline-flex items-center space-x-2 text-pazos-navy hover:text-pazos-yellow transition-colors"
                    >
                      <MessageCircle size={16} />
                      <span className="text-sm font-medium">Consultar más detalles</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Additional Help Section */}
        <div className="mt-12 bg-pazos-navy rounded-2xl p-8 text-white text-center">
          <h3 className="text-2xl font-bold mb-4">¿Tienes Otras Preguntas?</h3>
          <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
            Nuestro equipo de expertos está disponible para resolver cualquier duda específica 
            sobre tu proyecto. Obtén asesoría personalizada sin compromiso.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => {
                const message = encodeURIComponent('Hola! Tengo algunas preguntas específicas sobre mi proyecto que no encontré en el FAQ. ¿Podrían ayudarme?');
                window.open(`https://wa.me/18492528368?text=${message}`, '_blank');
              }}
              className="cta-button inline-flex items-center space-x-3 py-3 px-6 rounded-lg font-semibold transform hover:scale-105 transition-all duration-300"
            >
              <MessageCircle size={20} />
              <span>Hacer Pregunta Específica</span>
            </button>
            
            <button
              onClick={() => {
                const message = encodeURIComponent('Hola! Me gustaría agendar una consulta técnica para revisar los detalles de mi proyecto.');
                window.open(`https://wa.me/18492528368?text=${message}`, '_blank');
              }}
              className="bg-transparent border-2 border-pazos-yellow text-pazos-yellow hover:bg-pazos-yellow hover:text-pazos-navy px-6 py-3 rounded-lg font-semibold transition-colors"
            >
              Consulta Técnica
            </button>
          </div>
        </div>

        {/* Trust Signal */}
        <div className="mt-8 text-center">
          <div className="inline-flex items-center px-4 py-2 bg-white rounded-full shadow-sm">
            <Shield className="w-5 h-5 text-pazos-yellow mr-2" />
            <span className="text-sm text-gray-600">
              <strong>Garantía de Satisfacción:</strong> 27 años de experiencia respaldan nuestras respuestas
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FAQSection; 