'use client';

import { MessageCircle, Play } from 'lucide-react';

const HeroSection = () => {
  const handleWhatsAppClick = () => {
    const message = encodeURIComponent('Hola! Me interesa solicitar una cotización para mi proyecto.');
    window.open(`https://wa.me/18492528368?text=${message}`, '_blank');
  };

  const handleScrollToContact = () => {
    const contactSection = document.getElementById('contacto');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Video Background */}
      <div className="absolute inset-0 w-full h-full">
        <iframe
          src="https://player.vimeo.com/video/1051259867?h=fc0f3fa380&background=1&autoplay=1&loop=1&muted=1&controls=0&playsinline=1"
          className="absolute inset-0 w-full h-full object-cover"
          style={{
            width: '100%',
            height: '100%',
            minWidth: '100vw',
            minHeight: '100vh',
            border: 'none'
          }}
          allow="autoplay; fullscreen; picture-in-picture"
          allowFullScreen
          title="Video Pazos Holding"
        />
        
        {/* Overlay oscuro para mejorar legibilidad */}
        <div className="absolute inset-0 bg-black bg-opacity-40"></div>
      </div>

      {/* Contenido del Hero */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="max-w-4xl mx-auto">
          {/* Badge Nuevo en RD */}
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-pazos-yellow bg-opacity-90 border border-pazos-yellow mb-6">
            <span className="text-pazos-navy font-semibold text-sm sm:text-base">
              ¡Nuevo en RD!
            </span>
          </div>

          {/* Título Principal */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold text-white mb-6 leading-tight">
            Construcción
            <span className="block text-pazos-yellow">Personalizada</span>
            <span className="block text-2xl sm:text-3xl lg:text-4xl xl:text-5xl font-normal mt-2">
              con 27 años de experiencia
            </span>
          </h1>

          {/* Subtítulo */}
          <p className="text-lg sm:text-xl lg:text-2xl text-white mb-8 max-w-3xl mx-auto leading-relaxed">
            Calidad, Innovación y Satisfacción Garantizada en cada proyecto
          </p>

          {/* Botones CTA */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            {/* CTA Principal */}
            <button
              onClick={handleWhatsAppClick}
              className="cta-button w-full sm:w-auto flex items-center justify-center space-x-3 px-8 py-4 text-lg font-bold rounded-lg shadow-2xl transform hover:scale-105 transition-all duration-300"
            >
              <MessageCircle size={24} />
              <span>Solicita Cotización Ahora</span>
            </button>

            {/* CTA Secundario */}
            <button
              onClick={handleScrollToContact}
              className="w-full sm:w-auto bg-transparent border-2 border-white text-white hover:bg-white hover:text-pazos-navy px-8 py-4 text-lg font-semibold rounded-lg transition-all duration-300 flex items-center justify-center space-x-3"
            >
              <Play size={20} />
              <span>Ver Proyectos</span>
            </button>
          </div>

          {/* Indicadores de Confianza */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-2xl mx-auto">
            <div className="text-center">
              <div className="text-3xl font-bold text-pazos-yellow mb-1">27+</div>
              <div className="text-sm text-white opacity-90">Años de Experiencia</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-pazos-yellow mb-1">500+</div>
              <div className="text-sm text-white opacity-90">Proyectos Completados</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-pazos-yellow mb-1">100%</div>
              <div className="text-sm text-white opacity-90">Satisfacción Garantizada</div>
            </div>
          </div>
        </div>
      </div>

      {/* Indicador de Scroll */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10">
        <div className="animate-bounce">
          <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
            <div className="w-1 h-3 bg-white rounded-full mt-2 animate-pulse"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection; 