'use client';

import { Award, Shield, Clock, CreditCard, Leaf, MessageCircle, Users, TrendingUp } from 'lucide-react';

const TrustSection = () => {
  const handleWhatsAppClick = () => {
    const message = encodeURIComponent('Hola! Me interesa conocer más sobre la experiencia de Pazos Holding en República Dominicana y sus garantías de calidad.');
    window.open(`https://wa.me/18492528368?text=${message}`, '_blank');
  };

  const trustSignals = [
    {
      icon: Award,
      title: '27 Años de Experiencia Internacional',
      description: 'Trayectoria comprobada desde México, ahora en República Dominicana. Cientos de proyectos exitosos respaldan nuestra expertise.',
      stat: '27+',
      statLabel: 'Años',
      highlight: 'Experiencia desde 1997'
    },
    {
      icon: Shield,
      title: 'Calidad Garantizada',
      description: 'Estructuras certificadas con garantía por escrito. Materiales premium importados y técnicas de construcción de vanguardia.',
      stat: '5',
      statLabel: 'Años Garantía',
      highlight: 'Garantía estructural completa'
    },
    {
      icon: Clock,
      title: 'Entrega Puntual',
      description: 'Cumplimos plazos acordados respetando tu tiempo. Metodología eficiente y prefabricación que reduce tiempos de obra.',
      stat: '100%',
      statLabel: 'Puntualidad',
      highlight: 'Obras entregadas a tiempo'
    },
    {
      icon: CreditCard,
      title: 'Financiamiento Directo',
      description: 'Planes de pago personalizados sin intermediarios. Piscinas desde $200 USD mensuales. Hacemos realidad tu proyecto hoy.',
      stat: '$200',
      statLabel: 'USD/mes',
      highlight: 'Desde piscinas básicas'
    },
    {
      icon: Leaf,
      title: 'Construcción Sostenible',
      description: 'Diseños eco-friendly con eficiencia energética y mínima huella ambiental. Alineados con tendencias verdes globales.',
      stat: '30%',
      statLabel: 'Menos Consumo',
      highlight: 'Eficiencia energética'
    }
  ];

  const marketStats = [
    {
      icon: TrendingUp,
      title: 'Mercado en Crecimiento',
      stat: '+10%',
      description: 'Crecimiento turístico 2024'
    },
    {
      icon: Users,
      title: 'Demanda Comprobada',
      stat: '8.3M',
      description: 'Turistas en RD (ene-sep 2024)'
    },
    {
      icon: Award,
      title: 'Ocupación Hotelera',
      stat: '90.7%',
      description: 'Punta Cana temporada alta'
    }
  ];

  return (
    <section id="confianza" className="py-16 bg-gradient-to-br from-pazos-navy to-pazos-navy-dark">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-pazos-yellow bg-opacity-20 border border-pazos-yellow mb-4">
            <span className="text-pazos-yellow font-semibold text-sm">
              🏆 Líderes en Construcción de Lujo
            </span>
          </div>
          
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            ¿Por Qué Elegir
            <span className="block text-pazos-yellow">Pazos Holding?</span>
          </h2>
          
          <p className="text-lg text-gray-300 max-w-3xl mx-auto">
            Somos la empresa mexicana líder en construcción especializada, 
            ahora en República Dominicana para aprovechar el boom turístico del país.
          </p>
        </div>

        {/* Market Context Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-12">
          {marketStats.map((stat, index) => (
            <div key={index} className="bg-white bg-opacity-10 rounded-xl p-6 text-center backdrop-blur-sm">
              <stat.icon className="w-8 h-8 text-pazos-yellow mx-auto mb-3" />
              <div className="text-2xl font-bold text-pazos-yellow mb-1">{stat.stat}</div>
              <div className="text-white font-semibold mb-1">{stat.title}</div>
              <div className="text-sm text-gray-300">{stat.description}</div>
            </div>
          ))}
        </div>

        {/* Trust Signals Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {trustSignals.map((signal, index) => (
            <div key={index} className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 group">
              <div className="flex items-center justify-between mb-6">
                <div className="p-3 bg-pazos-yellow bg-opacity-20 rounded-full group-hover:bg-opacity-30 transition-colors">
                  <signal.icon className="w-8 h-8 text-pazos-navy" />
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-pazos-navy">{signal.stat}</div>
                  <div className="text-sm text-gray-500">{signal.statLabel}</div>
                </div>
              </div>
              
              <h3 className="text-xl font-bold text-pazos-navy mb-3">{signal.title}</h3>
              <p className="text-gray-700 mb-4">{signal.description}</p>
              
              <div className="inline-flex items-center px-3 py-1 bg-pazos-yellow bg-opacity-20 rounded-full">
                <span className="text-sm text-pazos-navy font-semibold">{signal.highlight}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Detailed Trust Builder */}
        <div className="bg-white rounded-2xl p-8 lg:p-12 shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-3xl font-bold text-pazos-navy mb-6">
                Tranquilidad Total en tu Inversión
              </h3>
              
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-pazos-yellow bg-opacity-20 rounded-full flex items-center justify-center">
                    <Shield className="w-6 h-6 text-pazos-navy" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-pazos-navy mb-2">Sin Sobrecostos Ocultos</h4>
                    <p className="text-gray-700">Presupuesto cerrado con contrato detallado. Lo que cotizamos es lo que pagas, sin sorpresas.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-pazos-yellow bg-opacity-20 rounded-full flex items-center justify-center">
                    <Users className="w-6 h-6 text-pazos-navy" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-pazos-navy mb-2">Equipo Local Capacitado</h4>
                    <p className="text-gray-700">Personal dominicano entrenado con estándares mexicanos. Conocemos el clima y normativas locales.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-pazos-yellow bg-opacity-20 rounded-full flex items-center justify-center">
                    <Award className="w-6 h-6 text-pazos-navy" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-pazos-navy mb-2">Gestión Completa de Permisos</h4>
                    <p className="text-gray-700">Nos encargamos de todos los trámites municipales y ambientales. Tú solo disfrutas el resultado.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-gradient-to-br from-pazos-navy to-pazos-navy-dark rounded-xl p-8 text-white">
                <h4 className="text-xl font-bold mb-4">Casos de Éxito Recientes</h4>
                <div className="space-y-4">
                  <div>
                    <div className="text-pazos-yellow font-semibold">Piscina Infinity • Punta Cana</div>
                    <div className="text-sm text-gray-300">Resort de 15 habitaciones • Entregado en 6 semanas</div>
                  </div>
                  <div>
                    <div className="text-pazos-yellow font-semibold">Domos Glamping • Jarabacoa</div>
                    <div className="text-sm text-gray-300">5 domos ecológicos • ROI 300% primer año</div>
                  </div>
                  <div>
                    <div className="text-pazos-yellow font-semibold">Chalets Villas • Santo Domingo</div>
                    <div className="text-sm text-gray-300">Residencia familiar • 40% ahorro vs construcción tradicional</div>
                  </div>
                </div>
              </div>

              <div className="text-center">
                <button
                  onClick={handleWhatsAppClick}
                  className="cta-button inline-flex items-center space-x-3 py-4 px-8 rounded-lg font-bold text-lg transform hover:scale-105 transition-all duration-300 shadow-lg"
                >
                  <MessageCircle size={24} />
                  <span>Hablar con un Experto</span>
                </button>
                <p className="text-sm text-gray-500 mt-2">Asesoría gratuita • Sin compromiso</p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-12">
          <div className="inline-block bg-pazos-yellow bg-opacity-20 rounded-xl p-6 backdrop-blur-sm">
            <h3 className="text-xl font-bold text-white mb-2">¿Listo para Comenzar tu Proyecto?</h3>
            <p className="text-gray-300 mb-4">Únete a cientos de clientes satisfechos que ya disfrutan de nuestras construcciones</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => {
                  const message = encodeURIComponent('Hola! Quiero solicitar una cotización gratuita para mi proyecto. ¿Podrían agendar una visita?');
                  window.open(`https://wa.me/18492528368?text=${message}`, '_blank');
                }}
                className="bg-pazos-yellow text-pazos-navy px-6 py-3 rounded-lg font-semibold hover:bg-yellow-400 transition-colors"
              >
                Cotización Gratuita
              </button>
              <button
                onClick={() => {
                  const message = encodeURIComponent('Hola! Me gustaría agendar una videollamada para conocer más sobre los servicios de Pazos Holding.');
                  window.open(`https://wa.me/18492528368?text=${message}`, '_blank');
                }}
                className="bg-white bg-opacity-20 text-white border border-white px-6 py-3 rounded-lg font-semibold hover:bg-opacity-30 transition-colors"
              >
                Agendar Videollamada
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TrustSection; 